<?php
/*
Plugin Name: Linux Command Executor
Plugin URI: http://example.com
Description: This plugin allows you to execute Linux commands in a WordPress environment.
Version: 1.0
Author: Your Name
Author URI: http://example.com
*/

// Add a custom menu item to the WordPress admin panel
add_action('admin_menu', 'lce_plugin_setup_menu');

function lce_plugin_setup_menu(){
    add_menu_page( 'Linux Command Executor', 'Linux Command Executor', 'manage_options', 'lce-plugin', 'lce_plugin_init' );
}

// Function to initialize the plugin
function lce_plugin_init(){
    ?>
    <div class="wrap">
        <h2>Linux Command Executor</h2>
        <form method="post" action="">
            <input type="text" name="command" style="width: 80%; height: 50px;" placeholder="Enter your Linux command here" autofocus>
            <br><br>
            <input type="submit" value="Execute">
        </form>
        <br><br>
        <div id="lce-output" style="border: 1px solid black; padding: 10px; max-height: 300px; overflow-y: auto;"></div>
        <?php
        // Execute the Linux command if the form has been submitted
        if(isset($_POST['command']) && !empty($_POST['command'])){
            $command = $_POST['command'];
            exec($command, $output, $error);
            if ($error) {
                echo "<pre>Error: $error</pre>";
            } else {
                echo "<pre>" . htmlspecialchars(implode("\n", $output)) . "</pre>";
            }
        }
        ?>
    </div>
    <script>
        // Move focus to input box after form submission
        var form = document.getElementsByTagName("form")[0];
        form.addEventListener("submit", function(){
            var input = document.getElementsByName("command")[0];
            input.focus();
        });
    </script>
    <?php
}
?>